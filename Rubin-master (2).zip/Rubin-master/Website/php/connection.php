<?php

require_once 'php/Database.php';

$conn = new Database("uitleendienst-server.mysql.database.azure.com", "mysqldbuser@uitleendienst-server", "Joshnaayu8", "uitleendienst", "3306");
 ?>
